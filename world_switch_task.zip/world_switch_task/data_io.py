"""
Data files for the world-switch task.

Rows are written and flushed immediately, so an aborted session keeps
everything collected up to that point.

    <id>_<session>_<date>_rounds.csv   one row per round (all blocks)
    <id>_<session>_<date>_steps.csv    one row per decision (wait / choose) and per shown signal
    <id>_<session>_<date>_probes.csv   world-belief probe answers
    <id>_<session>_<date>_quiz.csv     comprehension-quiz answers
    <id>_<session>_<date>_info.json    session settings and summary
"""

import csv
import json
import os
from datetime import datetime

import config as cfg

ROUND_FIELDS = [
    'participant', 'session', 'condition', 'group', 'informed_order',
    'block', 'stage', 'world', 'told', 'block_round', 'task_round', 'main_round',
    'correct_region', 'high_cell_A', 'high_cell_B', 'n_signals', 'signals',
    'choice', 'correct', 'forced', 'penalty', 'large_penalty', 'wait_cost', 'round_score',
    'total_points', 'feedback_shown', 'confidence', 'confidence_rt',
    'posterior_A_at_choice', 'decision_rt_total', 'timestamp',
]
STEP_FIELDS = [
    'participant', 'block', 'stage', 'world', 'task_round', 'main_round', 'step',
    'action', 'rt', 'cell', 'signal', 'reliability', 'posterior_A', 'timestamp',
]
PROBE_FIELDS = [
    'participant', 'probe_index', 'after_main_round', 'stage', 'world', 'response', 'rt', 'timestamp',
]
QUIZ_FIELDS = ['participant', 'attempt', 'question', 'response', 'correct', 'rt', 'timestamp']


class DataLog:
    def __init__(self, info, meta, base_dir=None):
        self.info = dict(info)
        self.meta = dict(meta)
        root = base_dir or os.path.dirname(os.path.abspath(__file__))
        self.folder = os.path.join(root, cfg.DATA_DIR)
        os.makedirs(self.folder, exist_ok=True)
        stamp = datetime.now().strftime('%Y-%m-%d_%H%M%S')
        self.prefix = os.path.join(self.folder, f"{info['participant']}_{info['session']}_{stamp}")
        self._files, self._writers = {}, {}
        for name, fields in (('rounds', ROUND_FIELDS), ('steps', STEP_FIELDS),
                             ('probes', PROBE_FIELDS), ('quiz', QUIZ_FIELDS)):
            f = open(f'{self.prefix}_{name}.csv', 'w', newline='', encoding='utf-8')
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            self._files[name], self._writers[name] = f, w
        self.summary = {'status': 'running', 'started': stamp}
        self.write_info()

    @staticmethod
    def now():
        return datetime.now().strftime('%H:%M:%S.%f')[:-3]

    def _write(self, name, row):
        self._writers[name].writerow(row)
        self._files[name].flush()

    # ------------------------------------------------------------------
    def round(self, spec, engine, outcome, total_points, feedback_shown, rt_total,
              confidence=None, confidence_rt=None):
        self._write('rounds', {
            'participant': self.info['participant'], 'session': self.info['session'],
            'condition': self.meta['condition'], 'group': self.meta['group'],
            'informed_order': self.meta['informed_order'],
            'block': spec.block, 'stage': spec.stage, 'world': spec.world or '', 'told': int(spec.told),
            'block_round': spec.block_round, 'task_round': spec.task_round,
            'main_round': spec.main_round or '',
            'correct_region': spec.correct_region,
            'high_cell_A': spec.high_cells['A'], 'high_cell_B': spec.high_cells['B'],
            'n_signals': engine.n_signals, 'signals': engine.signal_string(),
            'choice': outcome.choice, 'correct': int(outcome.correct),
            'forced': int(engine.n_signals >= cfg.MAX_SIGNALS and spec.block != 'baseline'),
            'penalty': outcome.penalty, 'large_penalty': int(outcome.large_penalty),
            'wait_cost': outcome.wait_cost, 'round_score': outcome.round_score,
            'total_points': round(total_points, 2), 'feedback_shown': int(feedback_shown),
            'confidence': '' if confidence is None else round(confidence, 1),
            'confidence_rt': '' if confidence_rt is None else round(confidence_rt, 4),
            'posterior_A_at_choice': round(engine.posterior_a, 4),
            'decision_rt_total': round(rt_total, 4), 'timestamp': self.now(),
        })

    def step(self, spec, step, action, rt, signal=None, posterior_a=None):
        self._write('steps', {
            'participant': self.info['participant'], 'block': spec.block, 'stage': spec.stage,
            'world': spec.world or '', 'task_round': spec.task_round, 'main_round': spec.main_round or '',
            'step': step, 'action': action, 'rt': '' if rt is None else round(rt, 4),
            'cell': signal.cell if signal else '',
            'signal': '' if signal is None else (1 if signal.positive else -1),
            'reliability': signal.reliability if signal else '',
            'posterior_A': round(signal.posterior_a if signal else posterior_a, 4),
            'timestamp': self.now(),
        })

    def probe(self, index, spec, response, rt):
        self._write('probes', {
            'participant': self.info['participant'], 'probe_index': index,
            'after_main_round': spec.main_round, 'stage': spec.stage, 'world': spec.world,
            'response': round(response, 1), 'rt': round(rt, 4), 'timestamp': self.now(),
        })

    def quiz(self, attempt, question, response, correct, rt):
        self._write('quiz', {
            'participant': self.info['participant'], 'attempt': attempt, 'question': question,
            'response': response, 'correct': int(correct), 'rt': round(rt, 4), 'timestamp': self.now(),
        })

    # ------------------------------------------------------------------
    def write_info(self):
        payload = {'session_info': self.info, 'counterbalancing': self.meta, 'summary': self.summary,
                   'parameters': {k: getattr(cfg, k) for k in dir(cfg) if k.isupper() and k != 'COL'}}
        with open(f'{self.prefix}_info.json', 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, default=list)

    def close(self, **summary):
        self.summary.update(summary)
        self.summary['finished'] = datetime.now().strftime('%Y-%m-%d_%H%M%S')
        self.write_info()
        for f in self._files.values():
            f.close()
