"""
Settings for the world-switch evidence-sampling task.

Every number used by the procedure lives here, so the task can be adjusted
without touching the block or drawing code.
"""

# ----------------------------------------------------------------------------
# Display
# ----------------------------------------------------------------------------
FULLSCREEN = True
WINDOW_SIZE = (1280, 720)      # used when FULLSCREEN is False (or with --windowed)
SCREEN_INDEX = 0
FONT = 'Arial'
SHOW_MOUSE = True

# Colour palette (hex), matching the demo video and slides
COL = {
    'bg': '#F7F8FB', 'ink': '#1C212B', 'muted': '#707885', 'line': '#D6DBE4',
    'white': '#FFFFFF', 'button_line': '#A0A8B6', 'hover': '#E5EDFC', 'disabled': '#EEF0F4',
    'blue': '#2F62D2', 'blue_t': '#E5EDFC', 'orange': '#D6742A', 'orange_t': '#FCEEE2',
    'green': '#229654', 'green_t': '#E2F5E9', 'red': '#CD3737', 'red_t': '#FCE6E6',
    'yellow': '#FFD65C', 'gold': '#A0780F', 'track': '#BEC4CE',
}

# ----------------------------------------------------------------------------
# Task parameters
# ----------------------------------------------------------------------------
REWARD_CORRECT = 10        # points for choosing the correct region
WAIT_COST = 0.8            # points per extra step of waiting (one more signal)
MAX_SIGNALS = 15           # submission is forced after this many signals
SMALL_PENALTY = 2          # wrong answer, lenient world (and 50% of the time in the harsh world)
LARGE_PENALTY = 30         # wrong answer, harsh world, with probability P_LARGE_HARSH
P_LARGE_HARSH = 0.5
REL_HIGH = 0.8             # thick-border cell: signal truthful 80% of the time
REL_LOW = 0.6              # thin-border cell: signal truthful 60% of the time
ENDOWMENT = 100            # starting points for the main task
BASELINE_REWARD = 1        # points per correct baseline answer (no penalties)

# ----------------------------------------------------------------------------
# Block sizes
# ----------------------------------------------------------------------------
N_PRACTICE = 6
BASELINE_SIGNAL_COUNTS = (1, 2, 3, 4, 6, 8)
BASELINE_REPEATS = 5       # 6 signal counts x 5 = 30 baseline rounds
N_PRIOR = 10
N_STAGES = 3
N_PER_STAGE = 50
N_INFORMED_PER_WORLD = 15
PROBE_EVERY = 10           # one world-belief probe every 10 main-task rounds (15 in total)
QUIZ_MAX_ATTEMPTS = 3      # after this many failed quiz attempts the session ends

# ----------------------------------------------------------------------------
# Counterbalancing (condition 1-4 = world order x informed-block order)
# ----------------------------------------------------------------------------
WORLD_ORDERS = {1: ('lenient', 'harsh', 'lenient'),
                2: ('harsh', 'lenient', 'harsh')}
INFORMED_ORDERS = {1: ('lenient', 'harsh'),
                   2: ('harsh', 'lenient')}

# ----------------------------------------------------------------------------
# Timing (seconds)
# ----------------------------------------------------------------------------
FLASH_DURATION = 0.5          # a newly lit cell flashes for this long
FEEDBACK_DURATION = 1.5       # feedback after each submission
ITI = 0.4                     # blank grid between rounds
BASELINE_SIGNAL_GAP = 0.35    # pause between the signals shown in baseline rounds
RECORDED_MSG_DURATION = 0.6   # "Recorded" message after a baseline rating

# ----------------------------------------------------------------------------
# Keys
# ----------------------------------------------------------------------------
QUIT_KEY = 'escape'           # saves what has been collected and ends the session
KEYBOARD_SHORTCUTS = True     # mouse is the main input; these keys work as well
KEY_WAIT = 'space'
KEY_REGION_A = 'left'
KEY_REGION_B = 'right'
KEY_CONTINUE = 'return'

# ----------------------------------------------------------------------------
# Output
# ----------------------------------------------------------------------------
DATA_DIR = 'data'
