"""
Task logic for the world-switch evidence-sampling task.

Nothing in this file touches PsychoPy: it builds the full trial schedule,
generates signals, keeps the ideal observer's within-round belief, and scores
each submission. The display code only asks this module what happens next.
"""

import random
import zlib
from dataclasses import dataclass, field

import config as cfg

REGIONS = ('A', 'B')
CELLS = {'A': ('A1', 'A2'), 'B': ('B1', 'B2')}
ALL_CELLS = ('A1', 'A2', 'B1', 'B2')


# ----------------------------------------------------------------------------
# Data containers
# ----------------------------------------------------------------------------
@dataclass
class RoundSpec:
    """Everything fixed in advance for one round."""
    block: str                      # practice / baseline / prior / main / informed
    world: str = None               # lenient / harsh / None (practice, baseline)
    stage: int = 0                  # 1-3 inside the main task, 0 elsewhere
    told: bool = False              # True only in the informed block
    block_round: int = 0            # 1..n inside its block
    task_round: int = 0             # number shown on screen
    main_round: int = 0             # 1..150 across the three main-task stages
    correct_region: str = 'A'
    high_cells: dict = field(default_factory=dict)   # e.g. {'A': 'A2', 'B': 'B1'}
    n_fixed_signals: int = 0        # baseline only
    probe_after: bool = False       # world-belief probe after this round
    announce_before: str = None     # informed block: world announced before this round


@dataclass
class Signal:
    cell: str
    positive: bool                  # True = check (cell's region is correct), False = cross
    reliability: float
    posterior_a: float              # ideal observer's P(Region A correct) after this signal


@dataclass
class Outcome:
    choice: str
    correct: bool
    n_signals: int
    gain: float                     # +10 when correct, else 0
    penalty: float                  # 0, 2 or 30
    large_penalty: bool
    wait_cost: float
    round_score: float
    scored: bool


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------
def region_of(cell):
    return cell[0]


def seed_from(participant, session):
    """Stable random seed from participant ID and session label."""
    return zlib.crc32(f'{participant}|{session}'.encode('utf-8'))


def condition_from(participant):
    """Counterbalancing condition 1-4 taken from the digits in the participant ID."""
    digits = ''.join(ch for ch in str(participant) if ch.isdigit())
    number = int(digits) if digits else seed_from(participant, 'cb')
    return (number - 1) % 4 + 1


def unpack_condition(condition):
    """Condition 1-4 -> (world-order group 1/2, informed-order 1/2)."""
    group = 1 + (condition - 1) % 2
    informed_order = 1 + (condition - 1) // 2
    return group, informed_order


def balanced_regions(n, rng):
    """Correct regions for n rounds: half A, half B, shuffled (odd n: the extra one is random)."""
    regions = ['A'] * (n // 2) + ['B'] * (n // 2)
    if n % 2:
        regions.append(rng.choice(REGIONS))
    rng.shuffle(regions)
    return regions


def random_high_cells(rng):
    """Which cell in each region has the thick border (80% reliable) this round."""
    return {'A': rng.choice(CELLS['A']), 'B': rng.choice(CELLS['B'])}


# ----------------------------------------------------------------------------
# Schedule
# ----------------------------------------------------------------------------
def build_schedule(condition, rng):
    """Full session schedule: a dict of block name -> list of RoundSpec."""
    group, informed_order = unpack_condition(condition)
    stage_worlds = cfg.WORLD_ORDERS[group]
    informed_worlds = cfg.INFORMED_ORDERS[informed_order]
    schedule = {}

    # 1. Practice
    schedule['practice'] = [
        RoundSpec('practice', block_round=i + 1, task_round=i + 1, correct_region=reg,
                  high_cells=random_high_cells(rng))
        for i, reg in enumerate(balanced_regions(cfg.N_PRACTICE, rng))]

    # 2. Baseline: fixed-sample inference
    counts = list(cfg.BASELINE_SIGNAL_COUNTS) * cfg.BASELINE_REPEATS
    rng.shuffle(counts)
    schedule['baseline'] = [
        RoundSpec('baseline', block_round=i + 1, task_round=i + 1, correct_region=reg,
                  high_cells=random_high_cells(rng), n_fixed_signals=n)
        for i, (reg, n) in enumerate(zip(balanced_regions(len(counts), rng), counts))]

    # 3. Prior block: same world as main-task stage 1, outcomes withheld
    schedule['prior'] = [
        RoundSpec('prior', world=stage_worlds[0], block_round=i + 1, task_round=i + 1,
                  correct_region=reg, high_cells=random_high_cells(rng))
        for i, reg in enumerate(balanced_regions(cfg.N_PRIOR, rng))]

    # 4-6. Main-task stages: one world per stage, unannounced switches between stages
    main, main_round = [], 0
    for stage, world in enumerate(stage_worlds, start=1):
        for i, reg in enumerate(balanced_regions(cfg.N_PER_STAGE, rng)):
            main_round += 1
            main.append(RoundSpec('main', world=world, stage=stage, block_round=i + 1,
                                  task_round=cfg.N_PRIOR + main_round, main_round=main_round,
                                  correct_region=reg, high_cells=random_high_cells(rng),
                                  probe_after=(main_round % cfg.PROBE_EVERY == 0)))
    schedule['main'] = main

    # 7. Informed block: each world announced before its 15 rounds
    informed, k = [], 0
    for world in informed_worlds:
        for i, reg in enumerate(balanced_regions(cfg.N_INFORMED_PER_WORLD, rng)):
            k += 1
            informed.append(RoundSpec('informed', world=world, told=True, block_round=k, task_round=k,
                                      correct_region=reg, high_cells=random_high_cells(rng),
                                      announce_before=world if i == 0 else None))
    schedule['informed'] = informed

    schedule['_meta'] = {'condition': condition, 'group': group, 'informed_order': informed_order,
                         'stage_worlds': stage_worlds, 'informed_worlds': informed_worlds}
    return schedule


# ----------------------------------------------------------------------------
# One round
# ----------------------------------------------------------------------------
class RoundEngine:
    """Generates signals and scores the submission for one round."""

    def __init__(self, spec, rng):
        self.spec = spec
        self.rng = rng
        self.signals = []
        self.posterior_a = 0.5

    @property
    def n_signals(self):
        return len(self.signals)

    def reliability(self, cell):
        return cfg.REL_HIGH if self.spec.high_cells.get(region_of(cell)) == cell else cfg.REL_LOW

    def draw_signal(self):
        """Light up a random cell (25% each) and return its check/cross signal."""
        cell = self.rng.choice(ALL_CELLS)
        rel = self.reliability(cell)
        truthful = self.rng.random() < rel
        in_correct_region = region_of(cell) == self.spec.correct_region
        positive = in_correct_region if truthful else not in_correct_region

        # Bayes update of P(A is correct) with the known reliability
        supports_a = (region_of(cell) == 'A') == positive
        lik_a = rel if supports_a else 1 - rel
        lik_b = 1 - lik_a
        p = self.posterior_a
        self.posterior_a = p * lik_a / (p * lik_a + (1 - p) * lik_b)

        sig = Signal(cell, positive, rel, self.posterior_a)
        self.signals.append(sig)
        return sig

    def resolve(self, choice, scored=True, charge_waiting=True):
        """Score a submission. Practice rounds are unscored; baseline rounds do not charge waiting."""
        correct = choice == self.spec.correct_region
        gain = cfg.REWARD_CORRECT if correct else 0
        penalty, large = 0, False
        if not correct:
            if self.spec.world == 'harsh' and self.rng.random() < cfg.P_LARGE_HARSH:
                penalty, large = cfg.LARGE_PENALTY, True
            else:
                penalty = cfg.SMALL_PENALTY
        wait_cost = cfg.WAIT_COST * self.n_signals if charge_waiting else 0
        score = gain - penalty - wait_cost if scored else 0
        return Outcome(choice, correct, self.n_signals, gain, penalty, large,
                       round(wait_cost, 2), round(score, 2), scored)

    def signal_string(self):
        """Compact record of the signals, e.g. 'A1+;B2-;B1+'."""
        return ';'.join(f"{s.cell}{'+' if s.positive else '-'}" for s in self.signals)


def make_rng(participant, session):
    return random.Random(seed_from(participant, session))
