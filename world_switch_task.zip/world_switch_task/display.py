"""
Drawing components for the world-switch task.

Layouts are written in a 1280 x 720 design space (origin top-left, y down),
the same space used for the demo video and slides. X(), Y() and S() map that
space onto PsychoPy 'height' units, so the screen keeps its proportions on any
monitor.
"""

import math

from psychopy import core, event, visual

import config as cfg

C = cfg.COL
DW, DH = 1280, 720
TEXT_SCALE = 1.15    # PsychoPy text height includes the line gap; this matches the demo's type size


def X(x):
    return (x - DW / 2) / DH


def Y(y):
    return (DH / 2 - y) / DH


def S(v):
    return v / DH


def to_design(pos):
    """PsychoPy height-unit position -> design coordinates."""
    return pos[0] * DH + DW / 2, DH / 2 - pos[1] * DH


class QuitSession(Exception):
    """Raised when the quit key is pressed."""


def rounded_vertices(w, h, r, n=8):
    r = max(0.0, min(r, w / 2, h / 2))
    corners = ((w / 2 - r, h / 2 - r, 0), (-w / 2 + r, h / 2 - r, 90),
               (-w / 2 + r, -h / 2 + r, 180), (w / 2 - r, -h / 2 + r, 270))
    pts = []
    for cx, cy, a0 in corners:
        for k in range(n + 1):
            a = math.radians(a0 + 90 * k / n)
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


# ----------------------------------------------------------------------------
# Screen: stimulus factories + interaction loop
# ----------------------------------------------------------------------------
class Screen:
    def __init__(self, win):
        self.win = win
        self.mouse = event.Mouse(win=win, visible=cfg.SHOW_MOUSE)
        self.px = win.size[1] / DH          # screen pixels per design pixel (for line widths)
        self._was_down = False

    # --- factories (design coordinates) --------------------------------------
    def rect(self, x0, y0, x1, y1, fill=None, line=None, lw=1.0, r=0, inset=True):
        if line and inset:                  # keep the stroke inside the box
            h = lw / 2
            x0, y0, x1, y1 = x0 + h, y0 + h, x1 - h, y1 - h
        w, h = S(x1 - x0), S(y1 - y0)
        verts = rounded_vertices(w, h, S(r)) if r > 0 else \
            [(-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)]
        return visual.ShapeStim(self.win, units='height', vertices=verts,
                                pos=(X((x0 + x1) / 2), Y((y0 + y1) / 2)),
                                fillColor=fill, lineColor=line,
                                lineWidth=lw * self.px if line else 0, closeShape=True)

    def text(self, s, x, y, size, color=None, bold=False, anchor=('left', 'top'), wrap=None):
        return visual.TextStim(self.win, units='height', text=s, pos=(X(x), Y(y)), height=S(size) * TEXT_SCALE,
                               color=color or C['ink'], font=cfg.FONT, bold=bold,
                               anchorHoriz=anchor[0], anchorVert=anchor[1], alignText=anchor[0],
                               wrapWidth=S(wrap) if wrap else None)

    def line(self, pts, color, lw):
        return visual.ShapeStim(self.win, units='height', vertices=[(X(x), Y(y)) for x, y in pts],
                                closeShape=False, fillColor=None, lineColor=color, lineWidth=lw * self.px)

    def circle(self, cx, cy, r, fill=None, line=None, lw=1.0):
        return visual.Circle(self.win, units='height', radius=S(r), pos=(X(cx), Y(cy)), edges=64,
                             fillColor=fill, lineColor=line, lineWidth=lw * self.px if line else 0)

    # --- interaction -------------------------------------------------------------
    def check_quit(self):
        if event.getKeys(keyList=[cfg.QUIT_KEY]):
            raise QuitSession()

    def get_click(self, buttons):
        """Enabled button pressed this frame (on the press, not while held), else None."""
        down = self.mouse.getPressed()[0]
        hit = None
        if down and not self._was_down:
            for b in buttons:
                if b.active() and b.contains(self.mouse):
                    hit = b
                    break
        self._was_down = down
        return hit

    def get_key(self, buttons):
        if not cfg.KEYBOARD_SHORTCUTS:
            return None
        keymap = {b.key: b for b in buttons if b.key and b.active()}
        if not keymap:
            return None
        for k in event.getKeys(keyList=list(keymap)):
            return keymap[k]
        return None

    def wait_for(self, buttons, draw, slider=None, on_frame=None):
        """Redraw every frame until one of the buttons is chosen. Returns (button, rt)."""
        event.clearEvents()
        self._was_down = self.mouse.getPressed()[0]
        t0 = core.getTime()
        while True:
            self.check_quit()
            if slider is not None:
                slider.update(self.mouse)
            if on_frame is not None:
                on_frame()
            for b in buttons:
                b.hover = b.active() and b.contains(self.mouse)
            draw()
            for b in buttons:
                b.draw()
            if slider is not None:
                slider.draw()
            self.win.flip()
            hit = self.get_click(buttons) or self.get_key(buttons)
            if hit is not None:
                for b in buttons:
                    b.hover = False
                return hit, core.getTime() - t0

    def show_for(self, duration, draw):
        """Redraw for a fixed duration; draw() receives the elapsed time."""
        t0 = core.getTime()
        while True:
            t = core.getTime() - t0
            if t >= duration:
                return
            self.check_quit()
            draw(t)
            self.win.flip()


# ----------------------------------------------------------------------------
# Button
# ----------------------------------------------------------------------------
class Button:
    def __init__(self, scr, box, label, size=17, key=None, r=10, bold=False):
        self.scr, self.box, self.key = scr, box, key
        self.enabled, self.visible, self.hover = True, True, False
        self.shape = scr.rect(*box, fill=C['white'], line=C['button_line'], lw=1.5, r=r)
        cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
        self.label = scr.text(label, cx, cy, size, C['ink'], bold=bold, anchor=('center', 'center'))
        self._fill, self._ink = C['white'], C['ink']

    def active(self):
        return self.enabled and self.visible

    def contains(self, mouse):
        return self.shape.contains(mouse)

    def set_label(self, s):
        if self.label.text != s:
            self.label.text = s

    def draw(self):
        if not self.visible:
            return
        if not self.enabled:
            fill, ink = C['disabled'], C['muted']
        else:
            fill, ink = (C['hover'] if self.hover else C['white']), C['ink']
        if fill != self._fill:
            self.shape.fillColor, self._fill = fill, fill
        if ink != self._ink:
            self.label.color, self._ink = ink, ink
        self.shape.draw()
        self.label.draw()


# ----------------------------------------------------------------------------
# The 2 x 2 grid
# ----------------------------------------------------------------------------
CELL = 160
CELL_POS = {'A1': (120, 172), 'A2': (120, 347), 'B1': (330, 172), 'B2': (330, 347)}


class Grid:
    def __init__(self, scr):
        self.scr = scr
        self.bg = [scr.rect(105, 130, 295, 522, fill=C['blue_t'], r=16),
                   scr.rect(315, 130, 505, 522, fill=C['orange_t'], r=16)]
        self.region_labels = [scr.text('Region A', 200, 104, 24, C['blue'], True, ('center', 'center')),
                              scr.text('Region B', 410, 104, 24, C['orange'], True, ('center', 'center'))]
        self.cells, self.flash, self.thick, self.thin = {}, {}, {}, {}
        self.names, self.rel_high, self.rel_low = {}, {}, {}
        for c, (x, y) in CELL_POS.items():
            self.cells[c] = scr.rect(x, y, x + CELL, y + CELL, fill=C['white'])
            self.flash[c] = scr.rect(x, y, x + CELL, y + CELL, fill=C['yellow'])
            self.thick[c] = scr.rect(x, y, x + CELL, y + CELL, line=C['ink'], lw=7)
            self.thin[c] = scr.rect(x, y, x + CELL, y + CELL, line=C['ink'], lw=2)
            self.names[c] = scr.text(c, x + 12, y + 8, 18, C['muted'])
            self.rel_high[c] = scr.text('80%', x + CELL - 12, y + 8, 18, C['ink'], True, ('right', 'top'))
            self.rel_low[c] = scr.text('60%', x + CELL - 12, y + 8, 18, C['muted'], False, ('right', 'top'))
        self.outline = {(reg, col): scr.rect(*box, line=C[col], lw=5, r=18, inset=False)
                        for reg, box in (('A', (101, 126, 299, 526)), ('B', (311, 126, 509, 526)))
                        for col in ('green', 'red')}
        self.high = {'A': 'A1', 'B': 'B1'}
        self.dots = {c: [] for c in CELL_POS}       # cell -> list of positive flags
        self._dot_stims = {c: [] for c in CELL_POS}

    def new_round(self, high_cells):
        self.high = dict(high_cells)
        self.dots = {c: [] for c in CELL_POS}
        self._dot_stims = {c: [] for c in CELL_POS}

    def add_dot(self, cell, positive):
        self.dots[cell].append(positive)
        self._layout_cell(cell)

    def _layout_cell(self, cell):
        """Three dots per row (as in the demo); a tighter layout once a cell has more than six."""
        x, y = CELL_POS[cell]
        flags = self.dots[cell]
        if len(flags) <= 6:
            cols, r, x0, y0, dx, dy = 3, 16, 34, 72, 46, 46
        else:
            cols, r, x0, y0, dx, dy = 4, 12, 26, 58, 36, 32
        self._dot_stims[cell] = [self._icon(x + x0 + (i % cols) * dx, y + y0 + (i // cols) * dy, r, ok)
                                 for i, ok in enumerate(flags)]

    def _icon(self, cx, cy, r, ok):
        scr = self.scr
        stims = [scr.circle(cx, cy, r, fill=C['green'] if ok else C['red'])]
        w = max(2.0, r * 0.22)
        if ok:
            stims.append(scr.line([(cx - r * .45, cy + r * .02), (cx - r * .1, cy + r * .38),
                                   (cx + r * .5, cy - r * .35)], C['white'], w))
        else:
            stims.append(scr.line([(cx - r * .38, cy - r * .38), (cx + r * .38, cy + r * .38)], C['white'], w))
            stims.append(scr.line([(cx - r * .38, cy + r * .38), (cx + r * .38, cy - r * .38)], C['white'], w))
        return stims

    def draw(self, flash=None, reveal=None, show_reliability=True):
        """flash = (cell, 0..1); reveal = (correct_region, chosen_region)."""
        for s in self.bg + self.region_labels:
            s.draw()
        for c in CELL_POS:
            self.cells[c].draw()
            if flash and flash[0] == c and flash[1] > 0:
                self.flash[c].opacity = flash[1]
                self.flash[c].draw()
            high = self.high.get(c[0]) == c
            (self.thick[c] if (high and show_reliability) else self.thin[c]).draw()
            self.names[c].draw()
            if show_reliability:
                (self.rel_high[c] if high else self.rel_low[c]).draw()
            for icon in self._dot_stims[c]:
                for s in icon:
                    s.draw()
        if reveal:
            correct, chosen = reveal
            self.outline[(correct, 'green')].draw()
            if chosen != correct:
                self.outline[(chosen, 'red')].draw()


# ----------------------------------------------------------------------------
# Right-hand panel during a round
# ----------------------------------------------------------------------------
class RoundPanel:
    def __init__(self, scr):
        t, r = scr.text, scr.rect
        self.points_box = r(600, 130, 1190, 205, fill=C['white'], line=C['line'], lw=1, r=14)
        self.points_label = t('Total points', 630, 150, 19, C['muted'])
        self.points_value = t('', 1160, 168, 30, C['ink'], True, ('right', 'center'))
        self.steps_box = r(600, 225, 1190, 335, fill=C['white'], line=C['line'], lw=1, r=14)
        self.steps_label = t('Steps waited this round', 630, 245, 19, C['muted'])
        self.steps_value = t('', 630, 280, 34, C['ink'], True)
        self.cost_text = t('', 830, 290, 21, C['muted'])
        self.note = t('', 630, 352, 18, C['red'], wrap=550)
        self.fb_box = r(600, 355, 1190, 598, fill=C['white'], line=C['line'], lw=1, r=16)
        self.fb_small = t('Feedback', 630, 372, 18, C['muted'])
        self.fb_title = t('', 630, 395, 32, C['green'], True)
        self.fb_rows = [(t('', 630, y, 24, C['ink']), t('', 1160, y, 26, C['ink'], True, ('right', 'top')))
                        for y in (448, 490, 542)]
        self.fb_sep = scr.line([(630, 530), (1160, 530)], C['line'], 2)
        self.fb_badge = r(618, 440, 1172, 480, fill=C['red'], r=8)
        self.fb_text = t('', 630, 452, 22, C['muted'], wrap=530)
        self.show_points = True
        self.show_feedback = False
        self.feedback_kind = None
        self.big_penalty = False

    def reset(self, points, show_points=True):
        self.show_points = show_points
        if points is not None:
            self.points_value.text = f'{points:.1f}'
        self.set_steps(0)
        self.note.text = ''
        self.show_feedback = False

    def set_points(self, points):
        self.points_value.text = f'{points:.1f}'

    def set_steps(self, n):
        self.steps_value.text = f"{n} step{'' if n == 1 else 's'}"
        self.cost_text.text = f'Waiting cost: -0.8 x {n} = -{cfg.WAIT_COST * n:.1f}'
        self.cost_text.color = C['red'] if n else C['muted']

    def set_note(self, s):
        self.note.text = s

    def set_feedback(self, kind, outcome, correct_region):
        """kind: 'visible' (scored), 'hidden' (prior block) or 'practice'."""
        self.show_feedback, self.feedback_kind, self.big_penalty = True, kind, False
        rows = [('', '', C['ink'])] * 3
        if kind == 'hidden':
            self.fb_title.text, self.fb_title.color = 'Choice recorded', C['ink']
            self.fb_text.text = 'The outcome of this round will be shown at the end of this block.'
        elif kind == 'practice':
            self.fb_title.text = f'Correct region: {correct_region}'
            self.fb_title.color = C['green'] if outcome.correct else C['ink']
            self.fb_text.text = ''
            rows = [('Practice: correct' if outcome.correct else 'Practice: wrong',
                     '', C['green'] if outcome.correct else C['red']),
                    ('Practice rounds are not scored.', '', C['muted']), ('', '', C['ink'])]
        else:
            self.fb_title.text = f'Correct region: {correct_region}'
            self.fb_title.color = C['green'] if outcome.correct else C['ink']
            self.fb_text.text = ''
            if outcome.correct:
                first = ('Correct answer', f'+{cfg.REWARD_CORRECT}', C['green'])
            elif outcome.large_penalty:
                first = ('Wrong answer: large penalty', f'-{outcome.penalty}', C['white'])
                self.big_penalty = True
            else:
                first = ('Wrong answer', f'-{outcome.penalty}', C['red'])
            n = outcome.n_signals
            rows = [first,
                    (f"Waited {n} step{'' if n == 1 else 's'}", f'-{outcome.wait_cost:.1f}', C['red']),
                    ('Round score', f'{outcome.round_score:+.1f}', C['ink'])]
        for (left, right), (lt, rt, col) in zip(self.fb_rows, rows):
            left.text, right.text = lt, rt
            left.color = right.color = col
            left.bold = (lt == 'Round score')

    def draw(self):
        if self.show_points:
            for s in (self.points_box, self.points_label, self.points_value):
                s.draw()
        for s in (self.steps_box, self.steps_label, self.steps_value, self.cost_text):
            s.draw()
        if self.note.text and not self.show_feedback:
            self.note.draw()
        if self.show_feedback:
            self.fb_box.draw()
            self.fb_small.draw()
            self.fb_title.draw()
            if self.big_penalty:
                self.fb_badge.draw()
            if self.fb_text.text:
                self.fb_text.draw()
            for left, right in self.fb_rows:
                left.draw()
                right.draw()
            if self.feedback_kind == 'visible':
                self.fb_sep.draw()


# ----------------------------------------------------------------------------
# Slider (no default value: the knob appears at the first click)
# ----------------------------------------------------------------------------
class Slider:
    def __init__(self, scr, x0, x1, y, vmin, vmax, left_label, right_label):
        self.scr, self.x0, self.x1, self.y = scr, x0, x1, y
        self.vmin, self.vmax = vmin, vmax
        self.track = scr.rect(x0, y - 3, x1, y + 3, fill=C['track'], r=3)
        self.fill = visual.Rect(scr.win, units='height', width=S(1), height=S(6), pos=(X(x0), Y(y)),
                                fillColor=C['blue'], lineColor=None)
        self.knob = scr.circle(x0, y, 11, fill=C['white'], line=C['blue'], lw=3)
        self.value_text = scr.text('', x0, y - 20, 17, C['blue'], True, ('center', 'bottom'))
        self.labels = [scr.text(left_label, x0, y + 18, 15, C['muted']),
                       scr.text(right_label, x1, y + 18, 15, C['muted'], anchor=('right', 'top'))]
        self.value, self.rated, self.dragging = None, False, False

    def update(self, mouse):
        down = mouse.getPressed()[0]
        if not down:
            self.dragging = False
            return
        mx, my = to_design(mouse.getPos())
        if not self.dragging:
            if self.x0 - 15 <= mx <= self.x1 + 15 and abs(my - self.y) <= 25:
                self.dragging = True
            else:
                return
        frac = min(1.0, max(0.0, (mx - self.x0) / (self.x1 - self.x0)))
        self.value = round(self.vmin + frac * (self.vmax - self.vmin))
        self.rated = True

    def draw(self):
        self.track.draw()
        for s in self.labels:
            s.draw()
        if self.value is None:
            return
        frac = (self.value - self.vmin) / (self.vmax - self.vmin)
        kx = self.x0 + frac * (self.x1 - self.x0)
        self.fill.width = S(max(1.0, kx - self.x0))
        self.fill.pos = (X((self.x0 + kx) / 2), Y(self.y))
        self.fill.draw()
        self.knob.pos = (X(kx), Y(self.y))
        self.knob.draw()
        self.value_text.text = f'{self.value:.0f}%'
        self.value_text.pos = (X(kx), Y(self.y - 20))
        self.value_text.draw()


# ----------------------------------------------------------------------------
# Header and centred cards
# ----------------------------------------------------------------------------
class Header:
    def __init__(self, scr):
        self.title = scr.text('', 80, 38, 30, C['ink'], True)
        self.rule = scr.line([(80, 86), (1200, 86)], C['line'], 1.5)

    def set(self, s):
        if self.title.text != s:
            self.title.text = s

    def draw(self):
        self.title.draw()
        self.rule.draw()


class Card:
    """A white rounded card with a title and wrapped body text."""

    def __init__(self, scr, box, title='', body='', title_color=None, body_size=22):
        x0, y0, x1, y1 = box
        self.box = scr.rect(x0, y0, x1, y1, fill=C['white'], line=C['line'], lw=1.5, r=16)
        self.title = scr.text(title, x0 + 40, y0 + 34, 30, title_color or C['ink'], True, wrap=x1 - x0 - 80)
        self.body = scr.text(body, x0 + 40, y0 + 92, body_size, C['ink'], wrap=x1 - x0 - 80)

    def draw(self):
        self.box.draw()
        self.title.draw()
        self.body.draw()
