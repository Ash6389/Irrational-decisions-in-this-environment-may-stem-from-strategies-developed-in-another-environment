"""
Participant-facing text for the world-switch task.

Kept separate from the procedure so the wording can be edited (or translated)
without touching any task code.
"""

INSTRUCTION_PAGES = [
    {
        'title': 'Welcome',
        'body': ('Thank you for taking part.\n\n'
                 'In every round of this task, one of two regions on the screen is the correct one. '
                 'Your goal is to find it while keeping as many points as possible.\n\n'
                 'The next pages explain how the task works. Use Continue and Back to move between pages.'),
        'demo': None,
    },
    {
        'title': 'The grid',
        'body': ('The screen shows a 2 x 2 grid.\n\n'
                 'The left column is Region A (cells A1 and A2). The right column is Region B (cells B1 and B2).\n\n'
                 'In every round the computer secretly picks one region as the correct region. '
                 'Both regions are equally likely.'),
        'demo': 'grid',
    },
    {
        'title': 'Collecting evidence',
        'body': ('Click "Wait one more step" to collect evidence. Each click costs 0.8 points and lights up '
                 'one of the four cells at random.\n\n'
                 'The cell then shows a green check (its region is the correct one) or a red cross '
                 '(its region is not the correct one).\n\n'
                 'Signals stay in the cells, so you do not need to remember them.'),
        'demo': 'signals',
    },
    {
        'title': 'Some cells are more reliable',
        'body': ('Signals are not always right.\n\n'
                 'In each region, one cell has a thick border: its signals are right 80% of the time. '
                 'The other cell has a thin border: its signals are right 60% of the time.\n\n'
                 'Which cell is which changes from round to round and is always marked on the screen.'),
        'demo': 'reliability',
    },
    {
        'title': 'Choosing a region',
        'body': ('Whenever you feel ready, click "Choose Region A" or "Choose Region B". '
                 'You may also choose straight away, without any signals.\n\n'
                 'After 15 signals you have to choose.'),
        'demo': 'buttons',
    },
    {
        'title': 'Points',
        'body': ('You start the main task with 100 points.\n\n'
                 '-  A correct choice earns 10 points.\n'
                 '-  Each extra step of waiting costs 0.8 points.\n'
                 '-  A wrong choice loses points: sometimes a small amount and sometimes a large amount '
                 '(up to 30 points). How often each happens is something you will learn from experience.\n\n'
                 'The rules may change during the session without notice.'),
        'demo': None,
    },
    {
        'title': 'Practice',
        'body': ('You will now play 6 practice rounds. They do not count, and wrong choices cost nothing.\n\n'
                 'Click Continue to start the practice.'),
        'demo': None,
    },
]

KEYBOARD_NOTE = ('\n\nKeyboard: Space = wait one more step, Left arrow = Region A, '
                 'Right arrow = Region B, Enter = Continue.')

QUIZ = [
    {
        'question': 'What happens each time you click "Wait one more step"?',
        'options': ['Nothing changes.',
                    'You lose 0.8 points and one cell shows a signal.',
                    'You gain 0.8 points.'],
        'answer': 1,
        'explain': 'Each extra step costs 0.8 points and lights up one cell at random.',
    },
    {
        'question': 'A cell shows a green check. What does that mean?',
        'options': ["The signal says that this cell's region is the correct one.",
                    'The round is over.',
                    'Only this single cell is correct.'],
        'answer': 0,
        'explain': "A check is a signal that the cell's region (A or B) is the correct region. Signals can be wrong.",
    },
    {
        'question': 'Which cells give more reliable signals?',
        'options': ['Cells with a thin border.',
                    'All cells are equally reliable.',
                    'Cells with a thick border.'],
        'answer': 2,
        'explain': 'Thick-border cells are right 80% of the time; thin-border cells are right 60% of the time.',
    },
    {
        'question': 'What can happen when you choose the wrong region?',
        'options': ['You always lose exactly 30 points.',
                    'You lose points: sometimes a small amount, sometimes a large amount (up to 30).',
                    'Nothing happens.'],
        'answer': 1,
        'explain': ('A wrong choice costs a small or a large penalty (up to 30 points). '
                    'How often each happens has to be learned from experience.'),
    },
]

QUIZ_INTRO = ('Quick check',
              'Before the main part, please answer 4 short questions about the rules.')
QUIZ_RETRY = ('One more look at the rules',
              'Some answers were not right. The instructions will be shown once more, '
              'followed by the questions.')

BASELINE_INTRO = ('Next part',
                  'In the next 30 rounds, the computer shows you a fixed number of signals; '
                  'you cannot ask for more.\n\n'
                  'Choose the region you think is correct, then rate how confident you are.\n\n'
                  'Each correct choice earns 1 point. There are no penalties, '
                  'and you will not see whether you were right.')
BASELINE_SHOWN = 'The computer is showing {n} signal{s}.'
BASELINE_CHOOSE = 'Which region is correct?'
CONFIDENCE_QUESTION = 'How confident are you that Region {region} is correct?'
RECORDED = 'Recorded.'

MAIN_INTRO = ('The main task',
              'The main task starts now.\n\n'
              'Waiting costs 0.8 points per signal, a correct choice earns 10 points, and a wrong choice '
              'costs a small or a large penalty (up to 30 points). How often each penalty occurs is for you '
              'to find out. The rules may change at any time without notice.\n\n'
              'For the first 10 rounds, the outcomes will be shown together at the end of those rounds.\n\n'
              'From time to time you will be asked a short question.')

PRIOR_REVEAL_TITLE = 'Outcomes of the last 10 rounds'

PROBE_TITLE = 'Quick question'
PROBE_QUESTION = 'If you answered wrong now, how likely is it that you would lose 30 points?'

BREAK = ('Short break', 'Take a short break if you like. Click Continue when you are ready.')

INFORMED_INTRO = ('Final part',
                  'In the final 30 rounds you will be told, before each set of 15 rounds, '
                  'which rule applies.\n\nEverything else stays the same.')
ANNOUNCE_TITLE = 'Next 15 rounds'
ANNOUNCE = {
    'lenient': ('You are now in the lenient world.\n\n'
                'A wrong choice always costs 2 points.'),
    'harsh': ('You are now in the harsh world.\n\n'
              'A wrong choice costs 30 points with 50% probability and 2 points with 50% probability.'),
}

END = ('Thank you!',
       'This is the end of the session.\n\n'
       'Main task: {main:.1f} points\n'
       'Baseline: {baseline} points\n\n'
       'Please let the experimenter know that you have finished.')
EXCLUDED = ('Thank you!',
            'The session ends here. Please let the experimenter know.')
