"""
Session procedure for the world-switch task.

Order (see README):
    1  instructions, practice (6), comprehension quiz (4 questions)
    2  baseline: fixed-sample inference (30)
    3  prior block (10, outcomes withheld, same world as stage 1)
    4-6 main-task stages 1-3 (3 x 50, unannounced world switches,
        world-belief probe every 10 rounds)
    7  informed block (2 x 15, world announced)
"""

import math

import config as cfg
import instructions as txt
from display import C, Button, Card, Grid, Header, RoundPanel, Screen, Slider
from task_logic import RoundEngine

N_MAIN_ROUNDS = cfg.N_PRIOR + cfg.N_STAGES * cfg.N_PER_STAGE
N_INFORMED = 2 * cfg.N_INFORMED_PER_WORLD
N_BASELINE = len(cfg.BASELINE_SIGNAL_COUNTS) * cfg.BASELINE_REPEATS


class Session:
    def __init__(self, win, schedule, log, rng):
        self.scr = Screen(win)
        self.schedule, self.log, self.rng = schedule, log, rng
        scr = self.scr

        self.header = Header(scr)
        self.grid = Grid(scr)
        self.panel = RoundPanel(scr)

        # round buttons (same layout as the demo)
        self.btn_wait = Button(scr, (105, 548, 295, 598), 'Wait one more step\n(-0.8)', 15, key=cfg.KEY_WAIT)
        self.btn_a = Button(scr, (305, 548, 400, 598), 'Choose\nRegion A', 15, key=cfg.KEY_REGION_A)
        self.btn_b = Button(scr, (410, 548, 505, 598), 'Choose\nRegion B', 15, key=cfg.KEY_REGION_B)
        self.round_buttons = [self.btn_wait, self.btn_a, self.btn_b]
        self.demo_buttons = [Button(scr, b.box, b.label.text, 15) for b in self.round_buttons]

        # navigation buttons
        self.btn_next = Button(scr, (900, 612, 1090, 662), 'Continue', 20, key=cfg.KEY_CONTINUE, bold=True)
        self.btn_back = Button(scr, (690, 612, 880, 662), 'Back', 20)
        self.btn_confirm = Button(scr, (960, 522, 1160, 572), 'Confirm', 20, key=cfg.KEY_CONTINUE, bold=True)

        # baseline panel
        self.base_box = scr.rect(600, 130, 1190, 598, fill=C['white'], line=C['line'], lw=1, r=16)
        self.base_info = scr.text('', 630, 160, 24, C['ink'], True, wrap=530)
        self.base_question = scr.text('', 630, 230, 22, C['ink'], wrap=530)
        self.base_recorded = scr.text(txt.RECORDED, 630, 470, 22, C['green'], True)

        self.points = float(cfg.ENDOWMENT)        # true running total of the main task
        self.shown_points = float(cfg.ENDOWMENT)  # what the participant currently sees
        self.baseline_points = 0
        self.probe_count = 0

    # ------------------------------------------------------------------
    # Whole session
    # ------------------------------------------------------------------
    def run(self):
        self.instructions()
        self.practice()
        if not self.quiz_with_retries():
            self.message(*txt.EXCLUDED, label='Finish')
            return 'excluded (comprehension quiz)'
        self.baseline()
        self.message(*txt.BREAK)
        self.prior_block()
        self.main_stages()
        self.message(*txt.BREAK)
        self.informed_block()
        title, body = txt.END
        self.message(title, body.format(main=self.points, baseline=self.baseline_points), label='Finish')
        return 'completed'

    # ------------------------------------------------------------------
    # Generic screens
    # ------------------------------------------------------------------
    def message(self, title, body, label='Continue'):
        card = Card(self.scr, (190, 100, 1090, 592), title, body)
        self.btn_next.set_label(label)
        self.scr.wait_for([self.btn_next], card.draw)
        self.btn_next.set_label('Continue')

    def round_title(self, spec):
        if spec.block == 'practice':
            return f'Practice round {spec.block_round} of {cfg.N_PRACTICE}'
        if spec.block == 'baseline':
            return f'Baseline round {spec.block_round} of {N_BASELINE}'
        if spec.block == 'informed':
            return f'Final part: round {spec.block_round} of {N_INFORMED}'
        return f'Round {spec.task_round} of {N_MAIN_ROUNDS}'

    def draw_round(self, flash=None, reveal=None, with_buttons=False, blank=False):
        self.header.draw()
        self.grid.draw(flash=flash, reveal=reveal, show_reliability=not blank)
        self.panel.draw()
        if with_buttons:
            for b in self.round_buttons:
                b.draw()

    def animate_signal(self, sig, draw):
        """Flash the lit cell; its check/cross appears part-way through the flash."""
        state = {'added': False}

        def frame(t):
            if not state['added'] and t >= 0.4 * cfg.FLASH_DURATION:
                self.grid.add_dot(sig.cell, sig.positive)
                state['added'] = True
            draw((sig.cell, math.sin(math.pi * min(1.0, t / cfg.FLASH_DURATION))))

        self.scr.show_for(cfg.FLASH_DURATION, frame)
        if not state['added']:
            self.grid.add_dot(sig.cell, sig.positive)

    # ------------------------------------------------------------------
    # 1. Instructions, practice, quiz
    # ------------------------------------------------------------------
    def instructions(self, repeat=False):
        pages = txt.INSTRUCTION_PAGES[:-1] if repeat else txt.INSTRUCTION_PAGES
        i = 0
        while i < len(pages):
            self.btn_back.visible = i > 0
            btn, _ = self.scr.wait_for([self.btn_back, self.btn_next], self.instruction_page(pages[i]))
            i = i - 1 if btn is self.btn_back else i + 1
        self.btn_back.visible = True

    def instruction_page(self, page):
        body = page['body']
        if page['demo'] == 'buttons' and cfg.KEYBOARD_SHORTCUTS:
            body += txt.KEYBOARD_NOTE
        if page['demo'] is None:
            card = Card(self.scr, (190, 100, 1090, 592), page['title'], body)
            return card.draw

        card = Card(self.scr, (560, 100, 1200, 592), page['title'], body, body_size=21)
        self.grid.new_round({'A': 'A1', 'B': 'B2'})
        if page['demo'] != 'grid':
            self.grid.add_dot('A1', True)
            self.grid.add_dot('B2', False)
        show_rel = page['demo'] in ('reliability', 'buttons')
        show_buttons = page['demo'] in ('signals', 'buttons')

        def draw():
            self.grid.draw(show_reliability=show_rel)
            if show_buttons:
                for b in self.demo_buttons:
                    b.draw()
            card.draw()
        return draw

    def practice(self):
        for spec in self.schedule['practice']:
            self.play_round(spec, 'practice')

    def quiz_with_retries(self):
        self.message(*txt.QUIZ_INTRO)
        for attempt in range(1, cfg.QUIZ_MAX_ATTEMPTS + 1):
            if self.quiz(attempt):
                return True
            if attempt < cfg.QUIZ_MAX_ATTEMPTS:
                self.message(*txt.QUIZ_RETRY)
                self.instructions(repeat=True)
        return False

    def quiz(self, attempt):
        all_correct = True
        for qi, q in enumerate(txt.QUIZ, start=1):
            card = Card(self.scr, (190, 90, 1090, 600), f'Question {qi} of {len(txt.QUIZ)}', q['question'])
            options = [Button(self.scr, (250, 262 + i * 74, 1030, 318 + i * 74), opt, 20)
                       for i, opt in enumerate(q['options'])]

            def ask():
                card.draw()

            btn, rt = self.scr.wait_for(options, ask)
            chosen = options.index(btn)
            correct = chosen == q['answer']
            all_correct &= correct
            self.log.quiz(attempt, qi, chosen, correct, rt)

            for b in options:
                b.enabled = False
            mark = self.scr.rect(*btn.box, line=C['green'] if correct else C['red'], lw=3, r=10, inset=False)
            feedback = self.scr.text(('Correct. ' if correct else 'Not quite. ') + q['explain'],
                                     250, 494, 21, C['green'] if correct else C['red'], wrap=780)

            def review():
                card.draw()
                for b in options:
                    b.draw()
                mark.draw()
                feedback.draw()

            self.scr.wait_for([self.btn_next], review)
        return all_correct

    # ------------------------------------------------------------------
    # Rounds with free waiting (practice, prior, main, informed)
    # ------------------------------------------------------------------
    def play_round(self, spec, mode):
        """mode: 'practice' (unscored), 'hidden' (prior block) or 'visible' (scored, feedback shown)."""
        engine = RoundEngine(spec, self.rng)
        self.grid.new_round(spec.high_cells)
        self.panel.reset(self.shown_points, show_points=(mode != 'practice'))
        self.header.set(self.round_title(spec))
        for b in self.round_buttons:
            b.enabled = b.visible = True

        rt_total = 0.0
        while True:
            btn, rt = self.scr.wait_for(self.round_buttons, self.draw_round)
            rt_total += rt
            if btn is self.btn_wait:
                sig = engine.draw_signal()
                self.log.step(spec, engine.n_signals, 'wait', rt, sig)
                self.animate_signal(sig, lambda fl: self.draw_round(flash=fl, with_buttons=True))
                self.panel.set_steps(engine.n_signals)
                if engine.n_signals >= cfg.MAX_SIGNALS:
                    self.btn_wait.enabled = False
                    self.panel.set_note(f'{cfg.MAX_SIGNALS} signals shown. Please choose a region.')
                continue
            choice = 'A' if btn is self.btn_a else 'B'
            self.log.step(spec, engine.n_signals + 1, f'choose_{choice}', rt, posterior_a=engine.posterior_a)
            break

        outcome = engine.resolve(choice, scored=(mode != 'practice'))
        if mode != 'practice':
            self.points += outcome.round_score
        if mode == 'visible':
            self.shown_points = self.points
            self.panel.set_points(self.shown_points)

        self.panel.set_feedback(mode, outcome, spec.correct_region)
        reveal = None if mode == 'hidden' else (spec.correct_region, choice)
        for b in self.round_buttons:
            b.enabled = False
        self.scr.show_for(cfg.FEEDBACK_DURATION, lambda t: self.draw_round(reveal=reveal, with_buttons=True))

        self.log.round(spec, engine, outcome, self.points if mode != 'practice' else 0,
                       feedback_shown=(mode != 'hidden'), rt_total=rt_total)

        self.panel.show_feedback = False
        self.panel.set_steps(0)
        self.panel.set_note('')
        self.grid.new_round(spec.high_cells)
        self.scr.show_for(cfg.ITI, lambda t: self.draw_round(with_buttons=True, blank=True))
        return outcome

    # ------------------------------------------------------------------
    # 2. Baseline: fixed-sample inference
    # ------------------------------------------------------------------
    def baseline(self):
        self.message(*txt.BASELINE_INTRO)
        for spec in self.schedule['baseline']:
            self.baseline_round(spec)

    def draw_baseline(self, flash=None, slider=None, recorded=False):
        self.header.draw()
        self.grid.draw(flash=flash)
        self.base_box.draw()
        self.base_info.draw()
        self.base_question.draw()
        for b in (self.btn_a, self.btn_b):
            b.draw()
        if recorded:
            self.base_recorded.draw()

    def baseline_round(self, spec):
        engine = RoundEngine(spec, self.rng)
        self.grid.new_round(spec.high_cells)
        self.header.set(self.round_title(spec))
        n = spec.n_fixed_signals
        self.base_info.text = txt.BASELINE_SHOWN.format(n=n, s='' if n == 1 else 's')
        self.base_question.text = ''
        self.btn_wait.visible = False
        self.btn_a.enabled = self.btn_b.enabled = False

        for i in range(n):
            sig = engine.draw_signal()
            self.log.step(spec, i + 1, 'shown', None, sig)
            self.animate_signal(sig, lambda fl: self.draw_baseline(flash=fl))
            self.scr.show_for(cfg.BASELINE_SIGNAL_GAP, lambda t: self.draw_baseline())

        self.base_question.text = txt.BASELINE_CHOOSE
        self.btn_a.enabled = self.btn_b.enabled = True
        btn, rt = self.scr.wait_for([self.btn_a, self.btn_b], lambda: self.draw_baseline())
        choice = 'A' if btn is self.btn_a else 'B'
        self.log.step(spec, n + 1, f'choose_{choice}', rt, posterior_a=engine.posterior_a)

        self.btn_a.enabled = self.btn_b.enabled = False
        self.base_question.text = txt.CONFIDENCE_QUESTION.format(region=choice)
        slider = Slider(self.scr, 650, 1140, 420, 50, 100, '50% (guessing)', '100% (certain)')
        self.btn_confirm.enabled = False

        def enable_confirm():
            self.btn_confirm.enabled = slider.rated

        _, conf_rt = self.scr.wait_for([self.btn_confirm], self.draw_baseline,
                                       slider=slider, on_frame=enable_confirm)

        outcome = engine.resolve(choice, scored=False, charge_waiting=False)
        outcome.penalty, outcome.gain = 0, (cfg.BASELINE_REWARD if outcome.correct else 0)
        outcome.round_score = outcome.gain
        self.baseline_points += outcome.gain

        self.scr.show_for(cfg.RECORDED_MSG_DURATION, lambda t: (self.draw_baseline(recorded=True), slider.draw()))
        self.log.round(spec, engine, outcome, self.baseline_points, feedback_shown=False, rt_total=rt,
                       confidence=slider.value, confidence_rt=conf_rt)
        self.btn_wait.visible = True

    # ------------------------------------------------------------------
    # 3. Prior block
    # ------------------------------------------------------------------
    def prior_block(self):
        self.message(*txt.MAIN_INTRO)
        results = [(spec, self.play_round(spec, 'hidden')) for spec in self.schedule['prior']]
        self.shown_points = self.points
        self.reveal_prior(results)

    def reveal_prior(self, results):
        scr = self.scr
        stims = [scr.rect(190, 70, 1090, 600, fill=C['white'], line=C['line'], lw=1.5, r=16),
                 scr.text(txt.PRIOR_REVEAL_TITLE, 230, 100, 28, C['ink'], True)]
        y = 158
        for spec, out in results:
            if out.correct:
                result, col = f'Correct  +{cfg.REWARD_CORRECT}', C['green']
            else:
                result, col = f"Wrong  -{out.penalty}{'  (large penalty)' if out.large_penalty else ''}", C['red']
            steps = f"{out.n_signals} step{'' if out.n_signals == 1 else 's'}  -{out.wait_cost:.1f}"
            stims += [scr.text(f'Round {spec.block_round}', 230, y, 20, C['muted']),
                      scr.text(result, 370, y, 20, col, out.large_penalty),
                      scr.text(steps, 700, y, 20, C['ink']),
                      scr.text(f'{out.round_score:+.1f}', 1050, y, 20, C['ink'], True, ('right', 'top'))]
            y += 36
        stims += [scr.line([(230, y + 8), (1050, y + 8)], C['line'], 2),
                  scr.text('Total points', 230, y + 22, 22, C['ink'], True),
                  scr.text(f'{self.points:.1f}', 1050, y + 22, 22, C['ink'], True, ('right', 'top'))]

        def draw():
            for s in stims:
                s.draw()
        self.scr.wait_for([self.btn_next], draw)

    # ------------------------------------------------------------------
    # 4-6. Main-task stages with world-belief probes
    # ------------------------------------------------------------------
    def main_stages(self):
        for spec in self.schedule['main']:
            self.play_round(spec, 'visible')
            if spec.probe_after:
                self.probe(spec)

    def probe(self, spec):
        self.probe_count += 1
        card = Card(self.scr, (240, 160, 1040, 530), txt.PROBE_TITLE, txt.PROBE_QUESTION, title_color=C['gold'])
        slider = Slider(self.scr, 300, 980, 395, 0, 100, '0%', '100%')
        confirm = Button(self.scr, (830, 460, 1010, 508), 'Confirm', 20, key=cfg.KEY_CONTINUE, bold=True)
        confirm.enabled = False

        def enable_confirm():
            confirm.enabled = slider.rated

        def draw():
            self.header.draw()
            card.draw()

        _, rt = self.scr.wait_for([confirm], draw, slider=slider, on_frame=enable_confirm)
        self.log.probe(self.probe_count, spec, slider.value, rt)

    # ------------------------------------------------------------------
    # 7. Informed block
    # ------------------------------------------------------------------
    def informed_block(self):
        self.message(*txt.INFORMED_INTRO)
        for spec in self.schedule['informed']:
            if spec.announce_before:
                self.message(txt.ANNOUNCE_TITLE, txt.ANNOUNCE[spec.announce_before])
            self.play_round(spec, 'visible')
